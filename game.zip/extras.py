"""Puzzles added after the chapters shipped.

Chapter 1: two flood-gate levers in the woods open the storm drain; past the
           drained chamber, a key in the old works opens the ladder gate.
Chapter 2: stack the wood, light the stove, take the rifle AND the knife.
           The Goat Man stays out there until you start butchering.
           A rifle hit stuns a monster for a second.
Chapter 3: four levers up top; down below, power the minecart and ride it
           through the boarded tunnel (hold W).
"""
import math
import random

import pygame

from engine import Mesh, MeshBuilder, T, RX, RY
from textures import L, EMIS
import world as W
import chapter2 as C2
import chapter3 as C3
import chapter4 as C4

CART_END_PAD = 0.2


def clamp(v, a, b):
    return a if v < a else (b if v > b else v)


def key_mesh():
    b = MeshBuilder()
    brass = (1.0, 0.78, 0.3)
    b.box((0, 0.02, 0), (0.06, 0.03, 0.26), L.METAL, brass)
    b.box((0, 0.02, -0.15), (0.12, 0.03, 0.1), L.METAL, brass)
    b.box((0.03, 0.02, 0.1), (0.05, 0.03, 0.04), L.METAL, brass)
    b.box((0.03, 0.02, 0.06), (0.05, 0.03, 0.03), L.METAL, brass)
    b.box((0, 0.045, -0.15), (0.05, 0.01, 0.05), L.GLOW + EMIS, (0.8, 0.65, 0.3))
    return b.array()


def c1_post_mesh():
    """A flood-gate release lever's concrete post, housing, warning bar and red lamp."""
    b = MeshBuilder()
    b.box((0, 0.7, -0.15), (0.5, 1.4, 0.3), L.CONCRETE, (0.7, 0.7, 0.68))
    b.box((0, 1.15, 0.02), (0.4, 0.6, 0.06), L.METAL, (0.55, 0.5, 0.45))
    b.box((0, 1.5, 0.03), (0.46, 0.07, 0.1), L.METAL, (0.85, 0.7, 0.2))
    b.box((0, 1.62, -0.15), (0.12, 0.12, 0.12), L.GLOW + EMIS, (1.0, 0.15, 0.1))
    return b.array()


def pick_spread(rng, cands, n, min_d, pos):
    """n random candidates at least min_d apart (relaxing if the map is tight)."""
    cands = list(cands)
    rng.shuffle(cands)
    for d in (min_d, min_d * 0.6, min_d * 0.3, 0.0):
        out = []
        for c in cands:
            p = pos(c)
            if all(math.hypot(p[0] - q[0], p[1] - q[1]) >= d for q in (pos(o) for o in out)):
                out.append(c)
                if len(out) == n:
                    return out
    return cands[:n]


def ray_sphere(o, d, c, r):
    ox, oy, oz = o[0] - c[0], o[1] - c[1], o[2] - c[2]
    bb = ox * d[0] + oy * d[1] + oz * d[2]
    cc = ox * ox + oy * oy + oz * oz - r * r
    disc = bb * bb - cc
    if disc < 0:
        return None
    t = -bb - math.sqrt(disc)
    return t if t > 0 else None


class ExtrasMixin:
    # ================================================================== setup
    def init_extras(self, prog):
        self.m_grate1 = Mesh(self.ctx, prog, C4.gate_mesh(2.0, 2.4, False))
        self.m_keygate = Mesh(self.ctx, prog, C4.gate_mesh(2.0, 3.4, False))
        self.m_key = Mesh(self.ctx, prog, key_mesh())
        self.m_cart = Mesh(self.ctx, prog, C3.cart_mesh())
        self.m_plank = Mesh(self.ctx, prog, C3.plank_mesh())
        self.m_lever_box = Mesh(self.ctx, prog, C3.lever_box_mesh())
        self.m_c1post = Mesh(self.ctx, prog, c1_post_mesh())
        self.find_spawn_spots()
        self.run_seed = 1
        self.mon_stun = {}
        self.reset_extras()

    # ================================================================== random spawns
    def find_spawn_spots(self):
        """Every place each puzzle piece could go. Worked out once; each new game picks from them."""
        from gridgrow import zones_of
        w = self.world
        cc = W.cell_center
        z1 = zones_of(w.g, '.~tWSX', 'WS')
        pre, post = z1.get((9, 18)), z1.get((8, 50))
        self.spots_valve, self.spots_key = [], []
        lx, _, lz = w.ladder_pos
        for r in range(W.ROWS):
            for c in range(W.COLS):
                if w.g[r][c] != '.':
                    continue
                zz = z1.get((c, r))
                if zz == pre and r >= 21:
                    for side, (dc, dr) in (('N', (0, 1)), ('S', (0, -1)), ('E', (1, 0)), ('W', (-1, 0))):
                        if w.kind(c + dc, r + dr) == '#':
                            self.spots_valve.append((c, r, side))
                elif zz == post:
                    x, z = cc(c, r)
                    if math.hypot(x - lx, z - lz) > 24:
                        self.spots_key.append((c, r))
        # the release levers: somewhere off the trail in the woods, clear of trees
        rng = random.Random(77)
        self.spots_c1lever = []
        for _ in range(4000):
            x, z = rng.uniform(-44, 44), rng.uniform(-44, 38)
            if float(W.path_dist(x, z)) < 6 or w.near_tree(x, z, 1.8) or math.hypot(x, z - 48) < 18:
                continue
            if math.hypot(x - W.START[0], z - W.START[1]) < 12:
                continue
            self.spots_c1lever.append((x, z, rng.uniform(-math.pi, math.pi)))
            if len(self.spots_c1lever) >= 80:
                break
        # the mine: four levers up top, the cart's power lever in the yard
        up = self.lv_up
        self.spots_up = [s for s in up.wall_spots('.') if s[1] >= 12 and not (10 <= s[0] <= 18 and 15 <= s[1] <= 21)]
        low = self.lv_low
        zl = zones_of(low.g, '.,MEXRGH', 'R')
        yard = zl.get((15, 5))
        self.spots_low = [s for s in low.wall_spots('.') if zl.get((s[0], s[1])) == yard and abs(s[0] - 15) > 1]
        # the deep sewer's fuses: anywhere in the sewers around the hall (not the hall itself)
        lv4 = self.lv4
        z4 = zones_of(lv4.g, '.,MEXRGH', 'GH')
        hc = (C4.HALL[0] + C4.HALL[2]) // 2, (C4.HALL[1] + C4.HALL[3]) // 2
        hz_ = z4.get(hc)
        self.spots_fuse = [(c, r) for r in range(lv4.rows) for c in range(lv4.cols)
                           if lv4.g[r][c] in '.,' and z4.get((c, r)) == hz_ and not C4.inside(C4.HALL, c, r)]

    def randomize_puzzles(self, seed):
        """Put every puzzle piece somewhere new. The same seed gives the same layout,
        which is how co-op players all get the same game."""
        self.run_seed = seed
        cc = W.cell_center
        w = self.world
        # chapter 1: five valves, two release levers, the ladder key
        rng = random.Random(seed * 10 + 1)
        picks = pick_spread(rng, self.spots_valve, len(w.valves), 18.0, lambda s: cc(s[0], s[1]))
        for v, (c, r, side) in zip(w.valves, picks):
            p, n = w.wall_point(c, r, side, 0.0, W.SEWER_FLOOR + 1.25, off=0.32)
            v.update(pos=p, yaw=math.atan2(n[0], n[2]), cell=(c, r), side=side)
        picks = pick_spread(rng, self.spots_c1lever, len(w.c1_levers), 30.0, lambda s: (s[0], s[1]))
        for lev, (x, z, yaw) in zip(w.c1_levers, picks):
            w.place_c1_lever(lev, x, z, yaw)
        if self.spots_key:
            c, r = rng.choice(self.spots_key)
            x, z = cc(c, r)
            w.key_pos = (x + rng.uniform(-0.3, 0.3), W.SEWER_FLOOR + 0.06, z + rng.uniform(-0.3, 0.3))
        # chapter 2: which firewood is out there
        rng = random.Random(seed * 10 + 2)
        pool = self.w2.wood_pool
        self.w2.wood_spots = pool[:3] + rng.sample(pool[3:], min(len(pool) - 3, C2.WOOD_SPOTS - 3))
        # chapter 3: the levers
        rng = random.Random(seed * 10 + 3)
        for lv, spots, d in ((self.lv_up, self.spots_up, 30.0), (self.lv_low, self.spots_low, 0.0)):
            picks = pick_spread(rng, spots, len(lv.levers), d, lambda s, lv=lv: lv.center(s[0], s[1]))
            for lev, (c, r, side) in zip(lv.levers, picks):
                p, yaw = lv.lever_spot(c, r, side)
                lev.update(pos=p, yaw=yaw)
        # chapter 4: the fuses
        rng = random.Random(seed * 10 + 4)
        lv4 = self.lv4
        picks = pick_spread(rng, self.spots_fuse, len(lv4.fuses), 20.0, lambda s: lv4.center(*s))
        for fu, (c, r) in zip(lv4.fuses, picks):
            x, z = lv4.center(c, r)
            fu.update(pos=(x + rng.uniform(-0.3, 0.3), lv4.y0 + 0.05, z + rng.uniform(-0.3, 0.3)), yaw=rng.random() * 6)
        # chapter 5's pieces are placed by its own level
        if hasattr(self, 'randomize_ch5'):
            self.randomize_ch5(random.Random(seed * 10 + 5))

    def reset_extras(self):
        w = self.world
        w.grate_open = 0.0
        w.keygate_open = 0.0
        for lev in w.c1_levers:
            lev.update(pulled=False, progress=0.0, angle=0.8)
        self.key_taken = False
        self.c1_lever_t = 0.0
        # chapter 2
        self.fire_lit = False
        self.has_knife = False
        self.bait_pos = None          # where the corn is on the snow
        self.bait_t = None            # seconds until a deer comes for it
        self.bait_left = 1.0
        # chapter 3
        self.cart_power = False
        self.c3_riding = False
        self.cart_s = 0.0
        self.cart_v = 0.0
        self.cart_send_t = 0.0
        self.cart_done = False
        lv = getattr(self, 'lv_low', None)
        if lv is not None:
            for pl in lv.planks:
                pl['broken'] = False
        self.mon_stun = {}
        self.mon_scare = {}

    def stunned(self, attr):
        return self.time < self.mon_stun.get(attr, -1.0)


    # ================================================================== chapter 1
    def c1_levers_pulled(self):
        return sum(1 for lev in self.world.c1_levers if lev['pulled'])

    def update_c1_extras(self, dt, keys):
        w = self.world
        p = self.player
        # levers: one press throws them (pull_lever_press); here they swing down
        for lev in w.c1_levers:
            if lev['pulled']:
                lev['angle'] += (2.371 - lev['angle']) * min(1.0, dt * 8)
        # the grate lifts once both are down
        if self.c1_levers_pulled() >= len(w.c1_levers) and w.grate_open < 1.0:
            w.grate_open = min(1.0, w.grate_open + dt / 3.5)
        # walking up to the shut grate
        if w.grate_open < 0.8 and p.z > 44.0 and abs(p.x) < 4.0 and 'grate' not in self.flags:
            self.flags.add('grate')
            self.message("A flood grate, locked over the drain.", 4)
            self.message("The sign: FLOOD CONTROL. RELEASE LEVERS IN THE WOODS.", 6)
            self.set_objective("Find the two flood-gate release levers in the woods. Look for the red lamps. (%d/2)"
                               % self.c1_levers_pulled())
        # the ladder gate
        if w.keygate_open > 0.0 and w.keygate_open < 1.0:
            w.keygate_open = min(1.0, w.keygate_open + dt / 2.0)
        lx, lz = self.keygate_spot()
        if w.keygate_open < 0.8 and math.hypot(p.x - lx, p.z - lz) < 3.0 and 'keygate' not in self.flags \
                and (w.drained or self.valves_done >= 5):
            self.flags.add('keygate')
            if not self.key_taken:
                self.message("A gate in front of the ladder, chained and padlocked.", 4.5)
                self.set_objective("Find the key to the ladder gate. Search the old works past the chamber.")

    def keygate_spot(self):
        gx, gz = W.OX + W.KEYGATE[0] * W.C + W.C / 2, W.OZ + W.KEYGATE[1] * W.C
        return gx, gz - 0.6

    def act_c1lever(self, a, frm):
        lev = self.world.c1_levers[a['i']]
        if lev['pulled']:
            return
        lev['pulled'] = True
        lev['progress'] = 1.0
        self.audio.play('clunk', 0.9 if frm is None else 0.5)
        n = self.c1_levers_pulled()
        if n < 2:
            self.message(("The lever drops with a bang. Somewhere a chain rattles. (%d/2)" % n) if frm is None else
                         ("%s pulled a release lever. (%d/2)" % (self.who(frm), n)), 4)
            self.set_objective("Find the two flood-gate release levers in the woods. Look for the red lamps. (%d/2)" % n)
        else:
            self.audio.play('gate', 0.6)
            self.message("Far off toward the creek, metal grinds. The flood grate is going up.", 5)
            self.set_objective("The drain is open. Follow the trail north to the creek.")

    def act_c1key(self, a, frm):
        if self.key_taken:
            return
        self.key_taken = True
        self.audio.play('wood_pick', 0.6)
        if frm is None:
            self.message("A brass key on a ring, stamped GATE 9. It was in his pocket.", 4.5)
        else:
            self.message("%s found the key." % self.who(frm), 4)
        self.set_objective("Take the key to the gate in front of the service ladder.")

    def act_c1gate(self, a, frm):
        w = self.world
        if w.keygate_open > 0:
            return
        w.keygate_open = 0.01
        lx, lz = self.keygate_spot()
        self.audio.play3d('gate', lx, lz, 60, 1.0)
        self.audio.play3d('clunk', lx, lz, 30, 0.8)
        if self.moose.active and self.mp_sim():
            self.moose.hear(lx, lz, 60.0)
        self.message("The padlock gives. The gate scrapes up.", 4)
        self.set_objective("Climb the service ladder.")

    def c1_focus_cands(self):
        w = self.world
        out = []
        for i, lev in enumerate(w.c1_levers):
            if not lev['pulled']:
                out.append(('c1lever', i, lev['pos']))
        if w.key_pos and not self.key_taken:
            out.append(('c1key', 0, w.key_pos))
        if w.keygate_open <= 0.0:
            gx, gz = self.keygate_spot()
            out.append(('keygate', 0, (gx, W.SEWER_FLOOR + 1.3, gz + 0.5)))
        return out

    def interact_c1(self, kind):
        if kind == 'c1key':
            self.mp_act('c1key')
            return True
        if kind == 'keygate':
            if self.key_taken:
                self.mp_act('c1gate')
            else:
                self.message("Locked. Chained shut with a padlock.", 2.5)
            return True
        return False

    def draw_c1_dyn(self, r, cam):
        w = self.world
        if cam[2] < 70:
            for lev in w.c1_levers:
                r.draw(self.m_c1post, model=T(*lev['base']) @ RY(lev['yaw']))
                r.draw(self.m_lever, model=T(*lev['pos']) @ RY(lev['yaw']) @ RX(lev['angle']))
            r.draw(self.m_grate1, model=T(0.0, 2.4 * w.grate_open, 47.72))
        if cam[2] > 100:
            gx, gz = self.keygate_spot()
            r.draw(self.m_keygate, model=T(gx, W.SEWER_FLOOR + 3.0 * w.keygate_open, gz + 0.6))
        if w.key_pos and not self.key_taken:
            r.draw(self.m_key, model=T(*w.key_pos) @ RY(0.7))

    def c1_label(self, kind, key):
        if kind == 'c1lever':
            return "[E] Pull the release lever", self.world.c1_levers[key]['progress']
        if kind == 'c1key':
            return "[E] Take the key", 0.0
        if kind == 'keygate':
            return ("[E] Unlock the gate" if self.key_taken else "Locked"), 0.0
        return None, 0.0

    # ================================================================== chapter 2
    def ch2_goat_phase(self):
        return self.ch2_phase in ('wood', 'fire', 'rifle', 'hunt')

    def stove_spot(self):
        return 0.6, -1.5

    def knife_spot(self):
        return 1.75, -1.25

    def ch2_extra_focus(self):
        p = self.player
        ph = self.ch2_phase
        sx, sz = self.stove_spot()
        if ph == 'fire' and math.hypot(p.x - sx, p.z - sz) < 1.6:
            return ('stove', 0)
        kx, kz = self.knife_spot()
        if ph in ('rifle', 'hunt') and not self.has_knife and math.hypot(p.x - kx, p.z - kz) < 1.5:
            return ('knife', 0)
        bx, bz = C2.BAIT_SPOT
        if ph in ('rifle', 'hunt') and self.bait_pos is None and not self.owns('bait') \
                and math.hypot(p.x - bx, p.z - bz) < 1.4:
            return ('baitsack', 0)
        inside = abs(p.x) < C2.CABIN_HX and abs(p.z) < C2.CABIN_HZ
        if ph == 'hunt' and self.bait_pos is None and self.holding('bait') and not inside                 and math.hypot(p.x, p.z - C2.CABIN_HZ) > 2.0:
            return ('baitdrop', 0)
        return None

    def bait_drop_spot(self):
        """Where the corn goes: just in front of your feet."""
        p = self.player
        f = p.fwd()
        n = math.hypot(f[0], f[2]) or 1.0
        return p.x + f[0] / n * 1.1, p.z + f[2] / n * 1.1

    def bait_drop_ok(self):
        x, z = self.bait_drop_spot()
        if abs(x) < C2.CABIN_HX + 0.6 and abs(z) < C2.CABIN_HZ + 1.0:
            return "Too close to the cabin."
        if float(C2.terrain_h2(x, z)) < C2.WL + 0.2:
            return "Not in the water."
        return None

    def take_bait(self):
        self.give('bait')
        self.audio.play('wood_pick', 0.6)
        self.message("A sack of feed corn. In your backpack. [Tab] to hold it.", 4)
        self.check_armed()

    def drop_bait(self):
        why = self.bait_drop_ok()
        if why:
            self.message(why, 2.5)
            return
        x, z = self.bait_drop_spot()
        self.take_item('bait')
        self.mp_act('bait', x=round(x, 2), z=round(z, 2))

    def act_bait(self, a, frm):
        if self.bait_pos is not None or self.ch2_phase != 'hunt':
            return
        self.bait_pos = (a['x'], a['z'])
        self.bait_t = max(0.0, random.uniform(*C2.BAIT_DELAY) - C2.BAIT_WALK)
        self.bait_left = 1.0
        self.audio.play('paper', 0.8)
        self.message(("You pour the corn out on the snow. Now back off, keep low, and wait." if frm is None else
                      "%s put the bait out." % self.who(frm)), 5)
        self.set_objective("Wait for a deer to come to the bait. Keep your distance and your lantern low.  "
                           "[Right mouse] aim  [Left mouse] fire")

    def update_bait(self, dt):
        """The corn on the snow: a deer walks in and is eating it 15-60 s after it goes down."""
        if self.bait_pos is None:
            return
        dr = self.deer
        if dr is None:
            if self.bait_t is not None and self.mp_sim():
                self.bait_t -= dt
                if self.bait_t <= 0:
                    self.bait_t = None
                    p = self.player
                    self.deer = C2.Deer(self.w2, random.Random(), bait=self.bait_pos, away=(p.x, p.z))
            return
        bx, bz = self.bait_pos
        if dr.state == 'graze' and math.hypot(dr.x - bx, dr.z - bz) < 1.6:
            self.bait_left = max(0.3, self.bait_left - dt / 90.0)

    def act_stove(self, a, frm):
        if self.fire_lit:
            return
        self.fire_lit = True
        self.ch2_phase = 'rifle'
        self.audio.play('match', 0.9)
        self.message(("The kindling catches. The stove roars." if frm is None else
                      "%s got the stove going." % self.who(frm)), 4)
        self.set_objective("Take the rifle from the rack, the knife from the table and the bait by the door.")

    def take_knife(self):
        self.has_knife = True
        self.audio.play('wood_pick', 0.6)
        self.message("A hunting knife. Sharp. In your backpack.", 3)
        self.check_armed()

    def check_armed(self):
        if self.ch2_phase != 'rifle':
            return
        need = [w for w, have in (("the rifle from the rack", self.has_rifle),
                                  ("the knife from the table", self.has_knife),
                                  ("the bait by the door", self.owns('bait'))) if not have]
        if not need:
            self.mp_act('armed')
        else:
            self.set_objective("Take %s too." % (need[0] if len(need) == 1 else ", ".join(need[:-1]) + " and " + need[-1]))

    def act_armed(self, a, frm):
        if self.ch2_phase != 'rifle':
            return
        self.ch2_phase = 'hunt'
        if frm is not None:
            self.message("%s is ready to hunt. Take a rifle and a knife." % self.who(frm), 4)
        self.set_objective("Pick a spot outside and put the bait down: hold it ([Tab]) and press [E]. "
                           "A deer will come to it.")

    def stove_lights(self):
        if self.chapter != 2 or not self.fire_lit:
            return []
        Y = C2.CABIN_Y
        k = 0.8 + 0.2 * math.sin(self.time * 9) * math.sin(self.time * 5.3 + 1.7)
        sx, sz = self.stove_spot()
        return [((sx, Y + 0.6, sz + 0.45), 6.0, (1.6 * k, 0.7 * k, 0.2 * k))]

    def rifle_hits_monster(self, eye, f):
        """A rifle round into the Goat Man (or the Moose Man on the run home) stuns him for a second."""
        cands = []
        gt = self.goat
        if gt is not None and self.ch2_goat_phase():
            fx, fz = math.sin(gt.yaw), math.cos(gt.yaw)
            cands.append(('goat', [((gt.x, gt.y + 1.3, gt.z), 0.75), ((gt.x + fx * 0.5, gt.y + 2.3, gt.z + fz * 0.5), 0.45)]))
        c = self.chaser2
        if c is not None and self.ch2_phase == 'run':
            cands.append(('chaser2', [((c['x'], c['y'] + 1.4, c['z']), 0.6), ((c['x'], c['y'] + 2.2, c['z']), 0.4)]))
        best = None
        for attr, spheres in cands:
            for ctr, rad in spheres:
                t = ray_sphere(eye, f, ctr, rad)
                if t is not None and t < 120 and (best is None or t < best[0]):
                    best = (t, attr, ctr)
        if best is None:
            return False
        t, attr, ctr = best
        self.stun_monster(attr)
        self.spawn_blood(ctr[0], ctr[1], ctr[2], 16, vel=(f[0] * 2, 1.5, f[2] * 2), spread=1.0)
        self.audio.play3d('goat_roar' if attr == 'goat' else 'call_near', ctr[0], ctr[2], 80, 0.8)
        self.message("It staggers -- and backs off.", 2.0)
        return True

    # ================================================================== chapter 3
    def cart_pos(self):
        lv = self.lv_low
        x, z0, _ = lv.rail
        return x, z0 + self.cart_s

    def cart_len(self):
        _, z0, z1 = self.lv_low.rail
        return z1 - z0

    def ch3_extra_focus(self):
        lv = self.lv
        if lv is not self.lv_low or self.c3_riding or self.cart_done:
            return None
        p = self.player
        cx, cz = self.cart_pos()
        if math.hypot(p.x - cx, p.z - cz) < 1.9:
            return ('cart', 0)
        return None

    def ch3_low_lever_done(self):
        self.cart_power = True
        self.audio.play('drain', 0.5)
        self.message("A motor coughs somewhere back in the yard. The minecart has power.", 5)
        self.set_objective("Get in the minecart. Hold [W] to drive it through the boards.")

    def interact_cart(self):
        if not self.cart_power:
            self.message("The minecart. Its motor is dead -- there must be power somewhere down here.", 3.5)
            self.set_objective("Find a way to power the minecart.")
            return
        if self.mp_on():
            self.message("Everyone has to get in.", 2.5)
            return
        self.start_cart()

    def start_cart(self):
        self.c3_riding = True
        self.cart_v = 0.0
        self.audio.play('clunk', 0.8)
        self.message("Hold [W]. Don't stop.", 3)

    def act_cart(self, a, frm):
        if a['s'] > self.cart_s:
            self.cart_s, self.cart_v = a['s'], a['v']

    def act_plank(self, a, frm):
        pl = self.lv_low.planks[a['i']]
        if pl['broken']:
            return
        pl['broken'] = True
        cx = self.lv_low.rail[0]
        self.audio.play3d('smash', cx, pl['z'], 40, 1.0)
        self.shake = max(getattr(self, 'shake', 0.0), 0.7)
        self.burst_debris(cx, self.lv_low.y0 + 1.2, pl['z'], 26, up=3.0, spread=2.5, size=(0.08, 0.5))

    def update_cart(self, dt, keys):
        """Riding: W drives forward, S rolls it back."""
        p = self.player
        lv = self.lv_low
        fwd = keys[pygame.K_w] or keys[pygame.K_UP]
        back = keys[pygame.K_s] or keys[pygame.K_DOWN]
        if fwd:
            self.cart_v = min(4.2, self.cart_v + 2.4 * dt)
        elif back:
            self.cart_v = max(-1.5, self.cart_v - 2.4 * dt)
        else:
            self.cart_v *= max(0.0, 1.0 - dt * 0.9)
        s = self.cart_s + self.cart_v * dt
        _, z0, _ = lv.rail
        for i, pl in enumerate(lv.planks):
            if pl['broken']:
                continue
            front = pl['z'] - z0 - 0.95
            if s > front and self.cart_s <= front + 0.01:
                if self.cart_v > 1.4:
                    self.mp_act('plank', i=i)
                    self.cart_v *= 0.55
                else:
                    s = front
                    if self.cart_v > 0.3:
                        self.audio.play('impact', 0.5)
                    self.cart_v = 0.0
                    self.message("Back up and hit it harder.", 2)
        self.cart_s = clamp(s, 0.0, self.cart_len())
        self.audio.loop('creak', clamp(abs(self.cart_v) / 3.0, 0, 0.8))
        self.shake = max(getattr(self, 'shake', 0.0) * (1 - dt * 2), clamp(abs(self.cart_v) / 4.2, 0, 1) * 0.12)
        self.cart_send_t -= dt
        if self.mp_on() and self.cart_send_t <= 0:
            self.cart_send_t = 0.25
            self.mp_tell('cart', s=round(self.cart_s, 2), v=round(self.cart_v, 2))
        # you're in the cart
        cx, cz = self.cart_pos()
        slot = self.mp.slot if self.mp_on() else 0
        p.x = cx + (-0.22 if slot % 2 == 0 else 0.22)
        p.z = cz + (-0.3 if slot < 2 else 0.3)
        p.vx, p.vz = 0.0, self.cart_v
        p.y = lv.y0 + 0.35
        p.smooth_y = p.y
        p.bob_amt = 0.0
        if self.cart_s >= self.cart_len() - CART_END_PAD:
            self.cart_v = 0.0
            self.c3_riding = False
            self.cart_done = True
            self.audio.loop('creak', 0.0)
            self.audio.play('clunk', 1.0)
            p.x = cx + 1.3
            p.y = lv.y0
            p.smooth_y = p.y
            self.message("The cart slams into the buffers. A huge cavern. Something big is lying in the middle of it.", 5)
            self.set_objective("Keep going. Find a way out of the mine.")
        self.update_debris(dt, lv.y0)

    def draw_c3_dyn(self, r, lv):
        if lv is not self.lv_low:
            return
        cx, cz = self.cart_pos()
        r.draw(self.m_cart, model=T(cx, lv.y0, cz))
        for pl in lv.planks:
            if not pl['broken']:
                r.draw(self.m_plank, model=T(lv.rail[0], lv.y0, pl['z']))
        for mesh, M in self.debris_extras():
            r.draw(mesh, model=M)
