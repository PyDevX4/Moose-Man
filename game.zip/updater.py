CAN_INSTALL = False

def tidy():
    pass

def check_async(cb):
    pass

def download(*a, **k):
    return None

def install(*a, **k):
    return False
